chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'https://moonfeed.app' });
});
