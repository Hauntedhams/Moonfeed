// If Chrome caps the popup window below our CSS height,
// shrink the iframe to match so the bottom nav stays in view.
const iframe = document.querySelector('iframe');
const h = window.innerHeight;
if (h < 680) {
  iframe.style.height = h + 'px';
  document.body.style.height = h + 'px';
}
