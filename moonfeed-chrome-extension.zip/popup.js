const APP_URL = 'https://moonfeed.app';

document.getElementById('launchBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: APP_URL });
  window.close();
});

document.querySelectorAll('.link[data-url]').forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: link.dataset.url });
    window.close();
  });
});
