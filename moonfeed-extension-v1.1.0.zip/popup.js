const APP_URL = 'https://moonfeed.app';

function openUrl(url) {
  window.open(url, '_blank');
}

document.getElementById('launchBtn').addEventListener('click', () => {
  openUrl(APP_URL);
});

document.querySelectorAll('.link[data-url]').forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    openUrl(link.dataset.url);
  });
});

function formatPrice(priceUsd) {
  const p = parseFloat(priceUsd);
  if (isNaN(p)) return '—';
  if (p < 0.000001) return '$' + p.toExponential(2);
  if (p < 0.0001) return '$' + p.toFixed(8).replace(/0+$/, '');
  if (p < 0.01) return '$' + p.toFixed(6);
  if (p < 1) return '$' + p.toFixed(4);
  if (p < 1000) return '$' + p.toFixed(2);
  return '$' + p.toLocaleString('en-US', { maximumFractionDigits: 0 });
}

function formatVolume(vol) {
  const v = parseFloat(vol);
  if (isNaN(v) || v === 0) return '';
  if (v >= 1_000_000) return 'Vol $' + (v / 1_000_000).toFixed(1) + 'M';
  if (v >= 1_000) return 'Vol $' + (v / 1_000).toFixed(0) + 'K';
  return 'Vol $' + v.toFixed(0);
}

async function loadTrending() {
  const list = document.getElementById('coinList');
  const loading = document.getElementById('loadingState');
  const errorEl = document.getElementById('errorState');

  try {
    // Fetch top boosted tokens (trending)
    const boostRes = await fetch('https://api.dexscreener.com/token-boosts/top/v1');
    if (!boostRes.ok) throw new Error('boost fetch failed');
    const boosts = await boostRes.json();

    const solanaTokens = Array.isArray(boosts)
      ? boosts.filter((t) => t.chainId === 'solana').slice(0, 10)
      : [];

    if (!solanaTokens.length) throw new Error('no solana tokens');

    const addresses = solanaTokens.map((t) => t.tokenAddress).join(',');
    const pairsRes = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${addresses}`
    );
    if (!pairsRes.ok) throw new Error('pairs fetch failed');
    const pairsData = await pairsRes.json();

    // Keep the highest-volume Solana pair per token, then take top 5
    const seen = new Set();
    const pairs = (pairsData.pairs || [])
      .filter((p) => p.chainId === 'solana' && p.priceUsd && !seen.has(p.baseToken.address) && seen.add(p.baseToken.address))
      .sort((a, b) => (b.volume?.h24 || 0) - (a.volume?.h24 || 0))
      .slice(0, 5);

    if (!pairs.length) throw new Error('no pairs');

    pairs.forEach((pair) => {
      const change = parseFloat(pair.priceChange?.h24 || 0);
      const isPos = change >= 0;
      const vol = formatVolume(pair.volume?.h24);

      const item = document.createElement('div');
      item.className = 'coin-item';
      item.innerHTML = `
        <div class="coin-info">
          <span class="coin-symbol">${pair.baseToken.symbol}</span>
          <span class="coin-name">${vol || pair.baseToken.name}</span>
        </div>
        <div class="coin-stats">
          <span class="coin-price">${formatPrice(pair.priceUsd)}</span>
          <span class="coin-change ${isPos ? 'positive' : 'negative'}">
            ${isPos ? '▲' : '▼'} ${Math.abs(change).toFixed(1)}%
          </span>
        </div>
      `;
      item.addEventListener('click', () => openUrl(pair.url));
      list.appendChild(item);
    });

    loading.style.display = 'none';
    list.style.display = 'flex';
  } catch (_err) {
    loading.style.display = 'none';
    errorEl.style.display = 'block';
  }
}

loadTrending();
